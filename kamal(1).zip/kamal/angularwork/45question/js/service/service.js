app.factory("countryService",function($http){
    return {
	  list: function(response)
	  {
      $http({method:'GET', url:'countries.json', cache:true}).success(response); 
	  },
      find:function(id,response){
	  $http({
		  method:'GET',
	    url:'country_' + id + '.json', 
	  cache:true
	  }).success(response);
	  }
	  
	};
	
	});
	
	