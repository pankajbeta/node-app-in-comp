app.filter('encodeURI',function(){
return window.encodeURI;
});