var app = angular.module('myApp', [ 'ngRoute']);
 
 app.config(function($routeProvider){
 $routeProvider.
 when('/view1',{
 controller:'Controller1',
 templateUrl:'js/view/view1.html'
 }).when('/view2/:fname/:lname',{
 controller: 'Controller2',
 templateUrl: 'js/view/view2.html'
 }).otherwise({redirectTo:'/index'});
 });

app.controller('Controller1',function($scope,$location){
 $scope.loadView2=function(){
 $location.path('/view2/'+$scope.fname+ '/' +$scope.lname);
 }
}).controller('Controller2',function($scope,$routeParams,$location){
 
$scope.first=$routeParams.fname;
 $scope.last=$routeParams.lname;
});
