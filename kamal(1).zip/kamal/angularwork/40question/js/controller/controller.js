 app.controller('controller1', function ($scope, countryService){
          countryService.list(function(data){
          $scope.myData =data;
        });
      });
	  
     app.controller('controller2', function ($scope, $routeParams, $http){
        $scope.name = $routeParams.countryName;
        $http.get('countries.json').success(function(data) {
          $scope.country = data.filter(function(entry){
            return entry.name === $scope.name;
          })[0];
        });
         
        });
   