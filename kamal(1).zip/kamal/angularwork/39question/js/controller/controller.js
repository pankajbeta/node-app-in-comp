 app.controller('controller1', function ($scope, $http){
        $http.get('countries.json').then(function(response) {
          $scope.myData =response.data;
        });
      });
     app.controller('controller2', function ($scope, $routeParams, $http){
        $scope.name = $routeParams.countryName;
        $http.get('countries.json').success(function(data) {
          $scope.country = data.filter(function(entry){
            return entry.name === $scope.name;
          })[0];
        });
         
        });
   