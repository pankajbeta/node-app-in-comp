var app = angular.module("myApp",['ngRoute']);
app.config(function($routeProvider){
 $routeProvider.
 when('/index',{
 controller:'person1',
 templateUrl:'index.html'
 }).
 when('/login',{
 controller:'person2',
 templateUrl:'js/view/login_form.html'
 }).when('/order',{
 controller: 'person3',
 templateUrl: 'js/view/order.html'
 }).when('/singup',{
 controller: 'person2',
 templateUrl: 'js/view/signup.html'
 }).when('/emptable',{
 controller: 'person2',
 templateUrl: 'js/view/emptable.html'
 }).
 otherwise({
	 redirectTo:'/index'
	 });
 //$locationProvider.html5Mode(true);
});