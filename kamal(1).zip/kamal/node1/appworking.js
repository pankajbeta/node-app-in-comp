var fs = require("fs");

fs.readFile('/Users/kamal.kishore/Desktop/kamal/node1/links.txt', function (err, data) {
   if (err){
      console.log(err);
      return;
   }
   console.log(data.toString());
});
console.log("Program Ended");