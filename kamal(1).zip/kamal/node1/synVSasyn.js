var fs =require("fs");

fs.readFile('/Users/kamal.kishore/Desktop/kamal/node1/input.txt',function(err,data)
{
if(err)
{
return console.error(err);
}
console.log("asynchrouns o/p:" + data.toString());
});

var data = fs.readFileSync('/Users/kamal.kishore/Desktop/kamal/node1/input.txt');

 console.log("synchrouns o/p:" + data.toString());
  
  console.log("program End");