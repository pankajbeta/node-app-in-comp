
 
 
 var fs = require("fs");

// Asynchronous - Opening File
console.log("Going to open file!");
      fs.open('/Users/kamal.kishore/Desktop/kamal/node1/input.txt', 'r+', function(err, fd) {
           if (err) {
                      return console.error(err);
                    }
                console.log("File opened successfully!");
    
	  
	  
	  fs.readFile('/Users/kamal.kishore/Desktop/kamal/node1/input.txt',function(err,fd)
	  {
		   if (err) {
                        return console.error(err);
                    }
				
				
				
      });
	  console.log(fd.toString());
	    });
		
		fs.close(fd,function(err)
	  {
		   if (err) {
                        return console.log(err);
                    }
				
				console.log("file closed successfullly");	 
				
      });
console.log("program end");	 