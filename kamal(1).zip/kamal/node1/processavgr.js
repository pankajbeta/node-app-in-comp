
function grab(flag) {
	var index = process.argv.indexOf(flag);
	return (index === -1) ? "vishesh" : process.argv[index+2];
}

//console.log(process.argv);
var greeting = grab('greeting');
var user = grab('user');

if (!user || !greeting) {
	console.log("You Blew it!");
} else {
	console.log(`Welcome ${user}, ${greeting}`);
}

