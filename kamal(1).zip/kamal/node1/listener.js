var events = require("events");

var eventEmitter = new events.EventEmitter();


var listener1 = function listener1(){
console.log("listener1 excutes");
};

 var listener2 = function listener2(){
	 console.log("listener excutes");
 };

// Bind the connection event with the listner1 function
eventEmitter.on('connection', listener1);
eventEmitter.on('connection', listener2);

var count=events.EventEmitter.listenerCount(eventEmitter,"connection");
console.log("No of listener:" + count);

// Fire the connection event 
eventEmitter.emit('connection');

var rem=eventEmitter.removeListener("connection",listener1);
console.log("no of listener" + rem);
eventEmitter.emit('connection');
console.log("Program Ended.");