var events = require("events");

var eventEmitter= new events.EventEmitter();

//creation of event handler
var connectHandler = function connected(){
	 
	 console.log("connection successful");
        
		eventEmitter.emit("Data Recived");  //fire a event .
}
eventEmitter.on("connection", connectHandler); //bind the event with function.//'connect handler is callback here'


//bind event handler with anoynmous function
eventEmitter.on('data_received', function(){
   console.log('data received succesfully.');
});
//event if fire with on
eventEmitter.emit("connection");

console.log("Program send");
