var count=0;
var time = setInterval(function () {
	count++;
	console.log(count);
if(count == 5){
clearInterval(time);
}
else{
	console.log( "Hello, World!");
}}, 2000);

 
