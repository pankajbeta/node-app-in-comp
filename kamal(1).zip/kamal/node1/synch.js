var fs = require("fs");

var data = fs.readFileSync('/Users/kamal.kishore/Desktop/kamal/node1/links.txt');

console.log(data.toString());
console.log("Program Ended");