angular.module('spBlogger').run(['state , function(state){ $state.go('allPosts'); }]);
