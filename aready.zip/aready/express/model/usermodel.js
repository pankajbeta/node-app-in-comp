var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var userSchema = new Schema({
 fname: String,
 email: { type: String, required: true, unique: true },
content: { type: String, required: true}
});

var User = mongoose.model('expr', userSchema);

module.exports = User;
