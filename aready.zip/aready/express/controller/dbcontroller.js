usermodel=require('../model/usermodel')
module.exports.add=function(req,res){
var user=new usermodel();
user.fname=req.body.fname;
user.email=req.body.email;
user.content=req.body.content;
user.save(function(err,data){
if(err){
console.log(err)
}
else{
res.send(data);
}
})
};
 

 
 
 
 module.exports.list=function(req,res){
	 usermodel.find({},function(err,blogs){
		 if(err){
			res.send(err)
		 }
		 else{
			 res.send(blogs);
		 }
	 })
 }
 
 
 
  module.exports.removeData=function (req, res){
	 var blog = new usermodel();
  usermodel.findById(req.params.id, function ( err, blog ){//usermodel is schema
    blog.remove(function (err, blog ){
      res.send(blog)
      console.log("delete");
    });
  });
}