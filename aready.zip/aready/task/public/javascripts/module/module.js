var app= angular.module('myapp',['ngRoute','ngStorage']);
app.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider
	  .when('/login', {
        templateUrl: 'javascripts/view/login.html',
        controller: 'ulogin'
      }). when('/signup', {
        templateUrl: 'javascripts/view/signup.html',
        controller: 'registerCtrl'
      })
	  .
      otherwise({
        redirectTo: '/index'
      });
	  
  }]);
  
  
  
  app.directive('fileModel', ['$parse', function ($parse) {
return {
    restrict: 'A',
    link: function(scope, element, attrs) {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                modelSetter(scope, element[0].files[0]);
            });
        });
    }
};
}]);
