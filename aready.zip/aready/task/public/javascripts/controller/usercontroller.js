
app.controller('ulogin',['$scope','$localStorage','$location','$http','authuser',function($scope,$localStorage,$location,$http,authuser) 
 {
console.log($localStorage.loginUser);//for login fetch from create user js service
$scope.dp = $localStorage.loginUser;
console.log($scope.dp+"dp me");
for(var i in $scope.dp)
{
	$scope.pp = $scope.dp;
	console.log($scope.pp);
	}
//
$scope.logOut=true; 
$scope.message="helloo";
$scope.clickCreateUser=true;

$scope.error = '';

 $scope.userlogin=function(){
	 authuser.Islogin($scope.email,$scope.password);
 }
 }]);


app.controller('registerCtrl',['$scope','$location','$http',function($scope,$location,$http){
$scope.uploadFile = function(){
	alert('submit');
        var file = $scope.myFile;
        var uploadUrl = "api/signup";
        var fd = new FormData();
        fd.append('name',$scope.name);
        fd.append('email',$scope.email);
        fd.append('password',$scope.password);
        fd.append('file', file);
		fd.append('gender',$scope.gender);
        //JSON.stringify({name:$scope.registration.user.name,email:$scope.registration.user.email,password:$scope.registration.user.password, file:file})
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(){
          console.log("success!!");
          $location.path("/login");
        })
        .error(function(){
          console.log("error!!");
        });
    };

}]);