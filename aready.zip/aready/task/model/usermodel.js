
var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var userSchema = new Schema({
 name: String,
 email: { type: String, required: true, unique: true },
 password: { type: String, required: true},
 file:String,
 gender:String
});



var User = mongoose.model('hello', userSchema);//here user is collection name in data base mlab

module.exports = User;
