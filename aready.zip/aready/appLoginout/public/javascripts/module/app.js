var app =angular.module('myApp', ['ngRoute' ,'ngMessages','ngStorage','ui.bootstrap'])
    app.config(['$routeProvider','$locationProvider', function($routeProvider,$locationProvider) {
        $routeProvider.
                   when('/signUp', {
                    templateUrl: 'javascripts/view/signup.html', 
                     controller: 'SignUp'
                   }).
                   when('/login', {
                    templateUrl: 'javascripts/view/login.html', 
                     controller: 'login'
                   }).
                when('/home', {
                 	templateUrl: 'javascripts/view/home.html', 
                     controller: 'HomeCtrl',
                     resolve:{
                      loggedin: checkLoggedin
                     }
                  }).
               otherwise({
                   redirectTo: '/login'
                   });
                $locationProvider.html5Mode({
                 enabled: true,
                requireBase: false
              });

}]);


//******************authentication for valid user 
var checkLoggedin = function($q, $timeout, $http, $location, $rootScope){
      // Initialize a new promise
      var deferred = $q.defer();
      $http.get('/api/loggedin').success(function(user){
        // Authenticated
        if(user !== '0'){
          //$timeout(deferred.resolve, 0);
        console.log("you are log in " + user);
          deferred.resolve();
             }
        // Not Authenticated
        else {
          $rootScope.message = 'You need to log in.';
          console.log("you are not log in " + user);
          deferred.reject();
         // $timeout(function(){deferred.reject();}, 0);
          $location.url('/login');
        }
      });
      return deferred.promise;
    };