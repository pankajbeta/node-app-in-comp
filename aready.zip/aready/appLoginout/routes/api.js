var express = require('express');
var router = express.Router();
var mime = require('mime-types')
var multer  = require('multer');
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var bCrypt = require('bcrypt-nodejs');
//var upload = multer({ dest: 'uploads/' });
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+mime.extension(file.mimetype));
    }
});
var upload = multer({ storage: storage });
//var upload = multer({ dest: 'uploads/' });
//var userController=require('../controller/userController');
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
var Usermodel = require('../model/userModel');
var upload = multer({ storage: storage });
/* GET home page. */
router.get('/loggedin', function(req, res) {
  res.send(req.isAuthenticated() ? req.user : '0');
});
//create the hash password and match the password
 var createHash = function(password){
        return bCrypt.hashSync(password, bCrypt.genSaltSync(10), null);
    }
var isValidPassword = function(user, password){
  console.log(user.local.password);
  return bCrypt.compareSync(password, user.local.password);
}

//*******************passsport Authentication for signup****************************//
passport.use('local-signup', new LocalStrategy({
    passReqToCallback : true
  },
  function(req, username, password, done) {
    findOrCreateUser = function(){
      // find a user in Mongo with provided username
      Usermodel.findOne({'local.username':username},function(err, user) {
        // In case of any error return
        if (err){
          console.log('Error in SignUp: '+err);
          return done(err);
        }
        // already exists
        if (user) {
          console.log('User already exists');
          return done(null, false, 
             req.flash('message','User Already Exists'));
        } else {
          var newUser = new Usermodel();
          newUser.local.username = username;
          newUser.local.password = createHash(password);
          newUser.local.email = req.body.email;
          newUser.local.name = req.body.name;
           newUser.local.gender = req.body.gender;
          newUser.local.pic = req.file.filename;
          // save the user
          newUser.save(function(err) {
            if (err){
              console.log('Error in Saving user: '+err);  
              throw err;  
            }
            console.log('User Registration succesful' + newUser);    
            return done(null, newUser);
          });
        }
      });
    };
    // Delay the execution of findOrCreateUser and execute 
    // the method in the next tick of the event loop
   process.nextTick(findOrCreateUser);
  }));

//*******************passsport Authentication****************************//
passport.use('local-login',new LocalStrategy(function(username, password, done) {

    Usermodel.findOne({'local.username': username }, function(err, user) {
      if (err) { return done(err); }
      if (!user) {
        return done(null, false, { message: 'Incorrect username.' });
      }
      //if (user.local.password != password) {
      //   return done(null, false, { message: 'Incorrect password.' });
      // }
      if(!isValidPassword(user,password)){
        console.log("incorrect password");
         return done(null, false, { message: 'Incorrect password.' });
       }
      return done(null, user);
     // console.log(user)
    });
  }));

//passport serialize user for their session
passport.serializeUser(function(user, done) {
  done(null, user.id);
});
//passport deserialize user 
passport.deserializeUser(function(id, done) {
  Usermodel.findById(id, function(err, user) {
    done(err, user);
  });
});
//********************************************
router.post('/login', passport.authenticate('local-login'), function(req, res) { 
  console.log(req.user)
  res.send(req.user);
});

router.get('/logout', function(req, res){
    req.logout();
    res.send(req.user)
    console.log("user is logout")
});

//router.post('/signup',upload.single('file'),userController.signup);
 router.post('/signup',upload.single('file'), passport.authenticate('local-signup'), function(req, res) {
   res.send(req.user);
 });

module.exports = router;