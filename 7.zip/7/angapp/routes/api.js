var express = require('express');
var router = express.Router();
var mime = require('mime-types');
//for multer*****************************************
var multer  = require('multer');
//var upload = multer({ dest: 'uploads/' });
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/uploads/')
		//uploads is folder name in public folder
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+mime.extension(file.mimetype));
    }
});
var upload = multer({ storage: storage });
//var upload = multer({ dest: 'uploads/' });
var Blogstorage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './public/blogUpload/')
    },
    filename: function (req, file, cb) {
    	console.log('file ',file);
        cb(null, Date.now()+'.'+mime.extension(file.mimetype));
    }
});

var upload = multer({ storage: storage });
var blogUpload = multer({ storage: Blogstorage });



//***************************************************************

// controllers

var userController = require('../controller/userController');



// routes 

router.post('/signup',upload.single('file'),userController.signup);
//sign up is function name in usercontroller.js
router.post('/login',userController.login);
router.post('/add',userController.add);
router.get('/list',userController.list);

//for get data in  getAllUser

module.exports = router;