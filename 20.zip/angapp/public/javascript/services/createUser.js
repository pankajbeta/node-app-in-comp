app.service('createUser',function($location,$http,$localStorage){
this.signUpuser = function(name,email,password,file){
       // var file = $scope.registration.user.myFile;
      var uploadUrl = "api/signup";
        var fd = new FormData();
        fd.append('name',name);
        fd.append('email',email);
        fd.append('password',password);
        fd.append('file', file);
        //JSON.stringify({name:$scope.registration.user.name,email:$scope.registration.user.email,password:$scope.registration.user.password, file:file})
       
	   $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(res){
         $localStorage.userData=res;

      
           //console.log($localStorage.userData)
          $location.path("/login")
        })
        .error(function(){
          console.log("error!!");
        });
    };
})



app.factory('Auth', function($http,$location, $localStorage){
var userLog;
var log;
// var userLogindata=$localStorage.LoginUser;
//console.log(userLog);
//var isLogin;
return{
    setUser : function(email,password){
       $http({
	method:"POST",
	url:'api/login',
	data:{email:email,password:password},
}).then(function successCallback(response) {
		// if(response.data.error){
		// 	//alert("username or password is not valid");
		//  //  $location.path('/login');
		// 	//error = response.data.error;
		// }else{
	    var  userLog=response.data;
       $localStorage.LoginUser=  userLog ;
       if($localStorage.LoginUser.email == email && $localStorage.LoginUser.password == password){
        log=$localStorage.LoginUser;
       	alert("You are valid user");
       	$location.path('/home');
       }else{
       	   	alert("You are not valid user plz sign in");
       	   		$location.path('/signUp');
       }
      //  console.log($localStorage.LoginUser.email);
       // isAuthorized= true;
	   //$location.path('/home');
	   //alert("You are valid user");
		
		//console.log(response);
	}, function errorCallback(response) {
		  console.log('error');
		    alert("username or password is not valid");
		   //$location.path('/login');
	});

    },
    isLoggedIn : function(){
    return (log)? log=true : log=false;
    console.log(log)
    },
   isLoggedOut : function(){
    return log =false;
    }
  }
  
})
