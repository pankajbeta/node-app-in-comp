//***************************homecontroller*****************************//
app.controller("homecontroller",function($scope,$http,$location){
	$http({
			method: 'GET',
			url: '/api/home'
		}).
		then(function successCallback(response) 
		{
			if(response.data.error)
			{
				$scope.error = response.data.error;
			}
			else
			{
				$scope.user = response.data; 
			}
		}, function errorCallback(response) 
		   {
			  console.log('error',response);
		   });
	
});
 


//*****************************logincontroller*************************//
 app.controller("Logincontroller",function($scope,$http,$location,$localStorage,auth)
 {
	 /*$scope.loginhide = function(){
		 
		 auth.$scope.userlogin=true;
	 }*/
	$scope.dpPic = $localStorage.myuserdata;
	for(var i in $scope.dpPic){
				$scope.user=$scope.dpPic[i];
				}
	//console.log($scope.dpPic);
	 $scope.signupPage= function()
	 {
		 $location.path('/signup');
	 }
	 
	$scope.loginpage = function(){
		
		auth.setTlogIn($scope.email,$scope.password);
		
	 	/*$http({
		  method: 'POST',
		  url: '/api/login',
		  data: {email:$scope.email, password:$scope.password},
		}).then(function successCallback(response) {
			if(response.data.error)
			{
				$scope.error = response.data.error;
			}
			else 
			{
		
				$scope.dp = response.data;
				$localStorage.pp = $scope.dp;
				
				console.log($localStorage.pp)
				$location.path('/#');
		    
			}
		}, function errorCallback(response) {
		    console.log('error',response);
		});*/
	 }
 });
 
 
 

//*****************************************signupcontroller*************************************//
app.controller("signupcontroller",function($scope ,$location, $http, $localStorage){
      
	   console.log($scope.cd);
	   $scope.signup = function(){
       var file = $scope.file;
      var uploadUrl = "api/signup";
        var fd = new FormData();
        fd.append('name',$scope.name);
        fd.append('email',$scope.email);
        fd.append('password',$scope.password);
        fd.append('file', $scope.file);
      
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(){
          //console.log("success!!");
          $location.path("/login")
        })
        .error(function(){
          console.log("error!!");
        });
    };
	
	
	
 
	
	
});


//*******************************contactcontroller****************************// 
app.controller("contactcontroller",function($scope ,$location, $http){
        
		$scope.contact = function(){
			$http({
			method: 'POST',
			url: '/api/contact',
			data: {name:$scope.name, email:$scope.email,  message:$scope.message}
		}).
		then(function successCallback(response) 
		{
			if(response.data.error)
			{
				$scope.error = response.data.error;
			}
			else
			{
	
				$location.path('/#');
			}
		}, function errorCallback(response) 
		   {
			  console.log('error',response);
		   });
	}

	
});


//*****************************************addblogcontroller*********************//
app.controller("addblogcontroller",function($scope,$http, $location){
	$scope.addblog = function(){
       var file = $scope.file;
	   //console.log(file);
       var uploadUrl = "api/addblog";
        var fd = new FormData();
        fd.append('title',$scope.title);
		fd.append('content',$scope.content);
		fd.append('tags',$scope.tags);
		fd.append('price',$scope.price);
        fd.append('file', file);
        
        $http.post(uploadUrl,fd, {
            transformRequest: angular.identity,
            headers: {'Content-Type': undefined}
        }) .success(function(){
          //console.log("success!!");
          $location.path("/listblog")
        })
        .error(function(){
          console.log("error!!");
        });
    };

	
});


//****************************************listblog**************************************//
app.controller("listblogcontroller",function($scope, $http, $localStorage,$location){
	$scope.info1 = $localStorage.user;  
	 $scope.blog1 =  $localStorage.dd;
	 $scope.blog3 =$localStorage.cart
       $http({
			method: 'GET',
			url: '/api/listblog'
		}).
		then(function successCallback(response) 
		{
			if(response.data.error)
			{
				$scope.error = response.data.error;
			}
			else
			{
				$scope.user = response.data;
                $scope.currentPage = 1;
				$scope.totalItems = $scope.user.length;
				$scope.entryLimit = 9; 
				$scope.noOfpages = Math.ceil($scope.totalItems / $scope.entryLimit);				
			}
		}, function errorCallback(response) 
		   {
			  console.log('error',response);
		   });
		   
    //deletelist
	$scope.deletelist = function(id) {
			$http({
			method: 'DELETE',
			url: '/api/delete/' + id
		}).
		then(function successCallback(response) 
		{
			if(response.data.error)
			{
				$scope.error = response.data.error;
			}
			else
			{
				$scope.user.forEach(function(values,index)
				{
					if(values._id == id)
					{
						$scope.user.splice(index,1);
					}
				});
			}
		}), function errorCallback(response) 
		   {
			  console.log('error',response);
		   };
		};
//viewblog
$scope.view = function(id) {
	//alert("hi");
			$http({
			method: 'GET',
			url: '/api/blogview/' + id
		}).
		then(function successCallback(response) 
		{
			if(response.data.error)
			{
				$scope.error = response.data.error;
			}
			else
			{
				$scope.blog = response.data;
				$localStorage.user=$scope.blog;
				//console.log($localStorage.user);
				$location.path('/blog1');
		    }
		
		}), function errorCallback(response) 
		   {
			  console.log('error',response);
		   };
		};
		
		//*****editBlog  		
	$scope.editBlog = function(id) 
	{
    $http({
    method:"GET",
    url:'/api/editblog/'+id,
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog=response.data;

        $localStorage.dd=$scope.Blog;
        
        //console.log( $scope.updateValue)
        $location.path('/editblog');
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });


    }
	
	//save editblog in database
	$scope.saveEditBlog = function(id) 
	{
    $http({
    method:"POST",
    url:'api/editblog/'+id,
	data:{title:$scope.blog1.title,content:$scope.blog1.content,tags:$scope.blog1.tags}
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog=response.data;

        $localStorage.dd=$scope.Blog;
        
        //console.log( $scope.updateValue)
        $location.path('/listblog');
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });


    }  
	
	
//***add to cart 
$scope.carts = [];
$scope.count=0;
$scope.addToCart = function(id) 
	{
		//console.log(id);
    $http({
    method:"get",
    url:'api/addcart/'+id
	//data:{title:$scope.blog1.title,content:$scope.blog1.content,tags:$scope.blog1.tags}
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog2=response.data;
		//console.log( $scope.Blog2);
      // $localStorage.dd=$scope.Blog;
	  $scope.carts.push($scope.Blog2);
	  $scope.count=$scope.count+1;
	  //console.log("items"+$scope.count);
	  $localStorage.cart = $scope.carts;
	  //console.log($scope.carts);
       // $location.path('/');
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });


    }  
	
	$scope.delete = function(index)
	{
		$scope.blog3.splice(index,1);
	}
	
	
	$scope.total = function()
	{
		var add =0;
		
		angular.forEach($scope.blog3,function(item, key){
			//console.log($scope.blog3);
            add += parseInt(item.price * item.qty);
			//console.log(add);
			});
		return add;
	 }
	 
	 
	 //***********customer details save
	 $scope.cd =$localStorage.customerdetail;
	$scope.saveUser = function()
	{
     $http({
            method:"POST",
            url:'api/costumer',
	        data:{name:$scope.name, email:$scope.email, address:$scope.address, phone:$scope.phone, pincode:$scope.pincode, state:$scope.state, city:$scope.city} 
         }).then(function successCallback(response)
		{
          if(response.data.error)
		   {
             $scope.error = response.data.error;
           }
		   else
		    {
             $scope.customer=response.data;
             console.log($scope.customer);
             $localStorage.customerdetail=$scope.customer;
             console.log($localStorage.customerdetail)
             $location.path('/costumerdetail');
            }
               //console.log(response);
        } , function errorCallback(response) 
		    {
              console.log('error',response);
            });
    }
	 
	/*$scope.subTotal=function(){
        var total=0.0;
        angular.forEach($scope.person.items, function(item,key){
            total += item.qty*item.cost;
        });
        return total;
    }; */
	 
	 $scope.succces= function()
     {
	   alert("shopping is done");
     }  

});	



//***************************editblogcontroller*****************************// 
/*app.controller("editblogcontroller",function($scope,$http,$localStorage,$location)
{    $cope.updateblog =  $localStorage.dd;
	$scope.editBlog = function(id) 
	{
    $http({
    method:"GET",
    url:'api/editblog/'+id,
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog=response.data;

        $localStorage.dd=$scope.Blog;
        
        //console.log( $scope.updateValue)
        $location.path('/editblog');
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });


    }
	
	//****save editblog in database
	$scope.saveEditBlog = function(id) 
	{
    $http({
    method:"POST",
    url:'api/editblog/'+id,
  }).then(function successCallback(response) {
      if(response.data.error){
        $scope.error = response.data.error;
      }else{
        $scope.Blog=response.data;

        $localStorage.dd=$scope.Blog;
        
        //console.log( $scope.updateValue)
        $location.path('/listblog');
      }
      //console.log(response);
    }, function errorCallback(response) {
      console.log('error',response);
    });


    }
});*/

//******************************************profile************************************//
/*app.controller("profilecontroller",function($scope, $http){
           $http({
			   method: 'GET',
			   url: '/api/profile'
		   }).
            then(function successCallback(response)
			{
			if(response.data.error)
			    { 
		           $scope.error=response.data.error;
		        }
		    else
		        {
			       $scope.user = response.data;
				   //console.log($scope.user);
		        }
		    }, function errorCallback(response)
		            {
			         console.log('error',response);
		            }
            )		   
           	   
});*/


//**********************************maincontroller****************************************//
app.controller("maincontroller",function($scope,$location,auth,$localStorage){
	$scope.clear = function(){
	$localStorage.cart = ''; 
	 };
	$scope.logout=function(){
	
		$scope.clear();
		$scope.userlogin = false;
		$location.path('/home');
	}
	$scope.userlogin = false;
	$scope.checkUserlogin = function(){
		if(auth.isLoggin)
		    {
		     $scope.userlogin =true;
		    }
         else
		    {
			 $scope.userlogin =false;
	
            }
	}
});