var mongoose = require('mongoose');

var Schema = mongoose.Schema;

var customerSchema = new Schema({
 name: {type:String},
 email: { type: String, required: true},
 Phone: Number,
 address: String,
 pincode: Number,
 city: String,
 State: String
});



var User = mongoose.model('customer', customerSchema);

module.exports = User;
