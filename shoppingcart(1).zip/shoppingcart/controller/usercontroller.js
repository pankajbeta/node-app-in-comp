//model
var Usermodel = require('../model/signupmodel');
var costumermodel = require('../model/costumermodel');
var nodemailer = require('nodemailer');
var transporter = nodemailer.createTransport('smtps://c.vicky1990123@gmail.com:qwertyui123.gmail.com');

//************************************ sign up user*******************************************//
module.exports.signup =  function(req, res) 
{
    var user = new Usermodel();
    user.name = req.body.name;
    user.email = req.body.email;
    user.password = req.body.password;
	user.file = req.file.filename;
	
    console.log(req.body);
    user.save(function (err, data) {
					if (err) 
					{
						//console.log(err);
						res.send(err);
						
					}
					else
						{
						//console.log("valueEnterd");
						res.send(data);
					    }
			
		})
	};
	
//****************** login user******************//
module.exports.login =  function(req, res) 
{
var email = req.body.email;
var password =req.body.password;

Usermodel.findOne({email:req.body.email},function(err,person){
	if(err)
	{ 
        //console.log(err);
		res.send(err);
	}
	else
	{
	      if(person)
		  {
			  if(person.password == password)
			  {
				  res.send(person);
			  }
			  else
			  {
				  //console.log("Invalid password");
			  res.send({error:'Invalid password'});
			  }
			  
		  }
		  
		  else
		  {
			  //console.log("Invalid Email");
			  res.send({error:'Email is invalid'});
			
		  }
	}
});
}


//********************profile************************//
module.exports.profile = function(req, res)
{
Usermodel.find({},function(err, data)
{
	if(err)
	{ 
        //console.log(err);
		res.send(err);
		
	}
	else
	{
		//console.log(data);
		res.send(data);
	
	}
})	
};
//********************customer model************************//
module.exports.register =  function(req, res) 
{
	
	costumermodel.findOne({},function(err,user)
	{
		
	
    var user = new costumermodel();
    user.name = req.body.name;
    user.email = req.body.email;
    user.phone = req.body.phone;
	user.address = req.body.address;
	user.pincode = req.body.pincode;
	user.state = req.body.state;
	user.city = req.body.city;
    console.log(req.body);
    user.update(function (err, data) 
	    {
					if (err) 
					{
						//console.log(err);
						res.send(err);
						
					}
					else
						{
						    var mailOptions = 
							{
                                from: req.body.email, // sender address
                                to: 'c.vicky1990123@gmail.com', // list of receivers
                                subject: 'Hello ✔', // Subject line
                                //text: 'Hello world 🐴', // plaintext body
                                html: 'Your shopping is done successfully' // html body
                            };

      // send mail with defined transport object
      transporter.sendMail(mailOptions, function(error, info)
	    {
           if(error)
	       {
              return console.log(error);
           }
             console.log('Message sent: ' + info.response);
        });
						
						res.send(user);
					    }
			
	})
	});
	};
	
	


	
