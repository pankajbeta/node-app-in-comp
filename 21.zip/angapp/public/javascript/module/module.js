var app= angular.module('myapp',['ngRoute','ngStorage']);
app.config(['$routeProvider',
  function($routeProvider) {
    $routeProvider.
	when('/', {
        templateUrl: 'javascript/view/home2.html',
        controller: 'viewController'
      }).when('/list', {
        templateUrl: 'javascript/view/list.html',
        controller: 'viewController'
      }). when('/update', {
        templateUrl: 'javascript/view/update.html',
        controller: 'viewController'
      }).
      when('/login', {
        templateUrl: 'javascript/view/login.html',
        controller: 'ulogin'
      }).
	   when('/profile', {
        templateUrl: 'javascript/view/profile.html',
        controller: 'ulogin'
      }).
	  when('/add', {
        templateUrl: 'javascript/view/add.html',
        controller: 'addcont'
	  }).
	 when('/blog', {
        templateUrl: 'javascript/view/blog.html',
        controller: 'blogcont'
	  }).
	  when('/register', {
        templateUrl: 'javascript/view/register.html',
        controller: 'registerCtrl'
	  })
	  .
	  when('/contact', {
        templateUrl: 'javascript/view/contact.html',
        controller: 'registerCtrl'
	  })
	  
	  .when('/:id', {
        templateUrl: function(){
			return 'javascript/view/bloger.html';
		},
        controller: 'viewController'
	  }).
      otherwise({
        redirectTo: '/home2'
      });
	  
  }]);
  
  
// directive for save file*****************************************************
app.directive('fileModel', ['$parse', function ($parse) {
return {
    restrict: 'A',
    link: function(scope, element, attrs) {
        var model = $parse(attrs.fileModel);
        var modelSetter = model.assign;

        element.bind('change', function(){
            scope.$apply(function(){
                modelSetter(scope, element[0].files[0]);
            });
        });
    }
};
}]);
