app.factory('authuser', function($http,$location,$localStorage){
	var currentUser;
	return {
        Islogin:function(email,password){
        	//console.log(email);
	 	    //console.log(pass);
        $http({
        	method:'POST',
        	url: '/api/login',
        	data:{email:email,password:password}
        }).then(function successCallback(response){
                currentUser = response.data;
                $localStorage.loginUser = currentUser;
                console.log(response.data);
                if($localStorage.loginUser.email == email)
                  {
			      alert("hello");
                 $location.path('/profile');
                  }

                 else{

                 console.log("You Entered worng Passwoed or email");
                 }


        	},function errorCallback(response){
        	 console.log('error',response);
                   });
        
        },


        isCurrentLogin:function(){
           return currentUser ? currentUser=true : currentUser=false;
        },

        isLogout:function(){
           return  currentUser=false;
        }


	};
});