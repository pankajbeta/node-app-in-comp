var express = require('express');
var router = express.Router();

var crypto =  require('crypto');
var uuid = require('node-uuid');
var bcrypt = require('bcrypt-nodejs');
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;
//var LocalStrategy = require('passport-local').Strategy;
var Usermodel=require("../model/userschema");
var multer=require('multer');
var mime=require('mime-types');
var path = require("path");
var nodemailer = require('nodemailer');

var transporter = nodemailer.createTransport('smtps://kamalkishore273@gmail.com:98167kishore@smtp.gmail.com');
var storage=multer.diskStorage({
	destination:function(req,file,cb){
		cb(null,'./public/uploads')
	},
	filename:function(req,file,cb){
		console.log('file',file);
		cb(null,Date.now() + '.' +mime.extension(file.mimetype));
	}
})
var upload = multer({ storage: storage });

//************************************ Authentication *******************************************
 function ensureAuthenticated(req,res,next){     
if (req.isAuthenticated()) {
        next();   
        }
     }
//********************************************bcrypt**********************************************
var createHash=function(password)
{
	return bcrypt.hashSync(password,bcrypt.genSaltSync(10),null);
}
var isValidpassword = function(user,password)
{
	return bcrypt.compareSync(password, user.local.password);
}	 


router.get('/loggedin', function(req, res) {
  res.send(req.isAuthenticated() ? req.user : '0');
});
router.get('/profile' ,ensureAuthenticated,function(req, res, next) {
	// console.log(req);
    res.send(req.isAuthenticated() ? req.user : '0');

 });
//**********using passport**********************
passport.use('local-signup', new LocalStrategy({
    passReqToCallback : true
  },
  function(req, username, password, done) {
    findOrCreateUser = function(){
      //send the randome number for email varrification
 var seed = crypto.randomBytes(20);
var authToken = crypto.createHash('sha1').update(seed + req.body.email).digest('hex');
 // find a user in Mongo with provided username
Usermodel.findOne({'local.username':username},function(err, user) {
        // In case of any error return
        if (err){ 
          console.log('Error in SignUp: '+err);
          return done(err);
        }
        // already exists
        if (user) {
          console.log('User already exists');
          return done(null, false, 
             req.flash('message','User Already Exists'));
        }else { 
		console.log(req.body);
          var newUser = new Usermodel();
          newUser.local.username = username;
          newUser.local.password = createHash(password);
          newUser.local.email = req.body.email;
          newUser.local.name = req.body.name;
          newUser.local.gender = req.body.gender;
          newUser.local.pic = req.file.filename;
          newUser.local.authToken = authToken;
          newUser.local.isAuthenticated=false;
       newUser.save(function(err,newUser) {
            if (err){
              console.log('Error in Saving user: '+err);  
             throw err;  
            }else{
 console.log('User Registration succesful' + newUser);    
 var authenticationURL = 'http://localhost:3002/api/verify_email?token=' + newUser.local.authToken;
 var mailOptions = {
    from: '"Fred Foo 👥" <foo@blurdybloop.com>', // sender address
    to: 'pankaj8007@gmail.com', // list of receivers
    subject: 'Hello ✔', // Subject line
    text: 'Hello world 🐴', // plaintext body
    html: '<b>Hello world 🐴</b>' // html body
};
 console.log(authenticationURL)
//************send email
//var data = req.body;
transporter.sendMail(mailOptions, function(error, info){
       if(error){
        return console.log(error);
     } 
        console.log(info);
        });
      return done(null, newUser);
       }
      });
     }   
    });
  }  // Delay the execution of findOrCreateUser and execute 
    // the method in the next tick of the event loop
   process.nextTick(findOrCreateUser);
  }));		
   
  //*****random function**
  function makeid()
{
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    for( var i=0; i < 10; i++ )
        text += possible.charAt(Math.floor(Math.random() * possible.length));

    return text;
}

//********passport login****
passport.use('local-login' ,new LocalStrategy(function(username, password, done) {
    Usermodel.findOne({'local.username': username }, function(err, user) {
      if (err) { return done(err); }
      if (!user) {
        return done(null, false, { message: 'Incorrect username.' });
      }
      if (!isValidpassword(user,password)) {
        return done(null, false, { message: 'Incorrect password.' });
      }
      return done(null, user);
     // console.log(user)
    });
  }));

//passport serialize user for their session
passport.serializeUser(function(user, done){
  done(null, user.id);
});
//passport deserialize user 
passport.deserializeUser(function(id, done) {
  Usermodel.findById(id, function(err, user) {
    done(err, user);
  });
});

//*********login**********
router.post('/login', passport.authenticate('local-login'), function(req, res) {
  res.send(req.user);
});

//********signup*******
 router.post('/signup',upload.single('file'), passport.authenticate('local-signup'), function(req, res) {
   res.send(req.user);
 });
 
 

  
  
  
//**********logout user*************************
router.get('/logout', function(req, res){
	req.logout();
	res.send(req.user)
	console.log("user is logout")
	// res.redirect('/login');
});


//dynamic route

router.get('/email/:id',function(req, res, next) {
  
Usermodel.findById(req.params.id,function(err,data){
	if(err){
		res.send(err)
	}else{
		res.send(data)
	}
})

});





module.exports = router;
