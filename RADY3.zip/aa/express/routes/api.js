var express = require('express');
var router = express.Router();
var addblogcontroller = require('../controller/dbcontroller');

router.post('/add',addblogcontroller.add);
router.get('/list',addblogcontroller.list);
router.delete('/delete/:id',addblogcontroller.removeData);
//it send the data to u controller list is(function name)addblogcontroller(variable)/list(router)



module.exports = router;