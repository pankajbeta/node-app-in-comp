app.controller('cont',function($scope){
})
app.controller('addcont',function($scope,$http,$location){
	$scope.add=function(){
		alert("submit");
	$http({
		method:'post',
		url:'/api/add',
		data:{fname:$scope.fname,email:$scope.email,content:$scope.content}
	}).then(function successCallback(response){
		if(response.data.error){
			res.send=responce.data.error
		}
		else{
			$location.path('/list');
			
		}
		},function errorCallback(response){
			console.log("error",response);
		});
	}
});
app.controller('list',function($scope,$http,$location){
	$http({
		method:'get',
		url:'/api/list',
	}).then(function successCallback(response){
		if(response.data.error){
		console.log(error)}
		else{
			$scope.user=response.data
		}
		},function errorCallback(response){
			console.log(response.data.error)
		})


$scope.remove=function(id){
$http({
	method:'delete',
	url:'/api/delete/'+ id
}).then(function(res) {
            $scope.user.forEach(function(value,index){
              if(value._id == id){
               $scope.user.splice(index,1);
			   }
			})
				  
	 }
        , function(error) {
            console.log(error);
        });
    };
	$scope.viewUser= function(){
		$location.path('/add')
	}
});