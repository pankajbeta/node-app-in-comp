var app=angular.module('myApp',['ngRoute']);
app.config(['$routeProvider',function($routeProvider){
$routeProvider
.when('/',{
       templateUrl:'javascripts/view/home.html',
	   controller:'cont'
      }).when('/list', {
        templateUrl: 'javascripts/view/list.html',
        controller: 'list'
      }).when('/add', {
        templateUrl: 'javascripts/view/add.html',
        controller: 'addcont'
      })
	  .when('/login', {
        templateUrl: 'javascripts/view/login.html',
        controller: 'cont'
      }).
      otherwise({
        redirectTo: '/index'
      });
	  
}]);
	  
