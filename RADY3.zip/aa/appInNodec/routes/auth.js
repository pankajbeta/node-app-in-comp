//******************for autnntication***************
module.exports.authn=function(req,res,next){
	if(req.session.username){
		next();
	}
	else
	{
		res.redirect('/login');
	}
}