// var Usermodel = require('../model/userModel');
// var LocalStrategy   = require('passport-local').Strategy;

// module.exports.signup=function(req,res){
// var user=new Usermodel();
// user.local.name=req.body.name;
// user.local.username=req.body.username;
// user.local.email=req.body.email;
// user.local.password=req.body.password;
// user.local.pic= req.file.filename;
// user.local.gender= req.body.gender;
// Usermodel.findOne({'local.email':req.body.email},function(err,person){
// 	if(err){
// 		console.log('err',err)
// 	}else{
// 		if(!person){
// 			user.save(function(err,person){
// 				if(err){
// 					res.send(err);
// 				}else{
// 					res.send(person);
// 					console.log(person);
// 					//res.redirect("/login")
// 				}
// 			});
// 		}else{
// 			res.send({error:"Email is already taken"});
// 		}
// 	}

// })
// }
//  var createHash = function(password){
//         return bCrypt.hashSync(password, bCrypt.genSaltSync(10), null);
//     }