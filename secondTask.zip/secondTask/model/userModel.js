var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var bcrypt   = require('bcrypt-nodejs');
var userSchema = new Schema({
	local: {
	username: {type: String, required: true, unique: true },
  name: String,
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  pic:String,
  gender:String
}
});
var User = mongoose.model('user', userSchema);
module.exports = User;


//decrypt password
// var createHash = function(password){
//  return bCrypt.hashSync(password, bCrypt.genSaltSync(10), null);
// }
