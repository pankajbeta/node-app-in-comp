app.controller("HomeCtrl", function($scope){
	$scope.message="hiii";
});

app.controller("login", function($scope,$location,$http,Auth,$localStorage){
$scope.userLogin=function(){
  Auth.setUser($scope.username,$scope.password); 
}
});
app.controller("SignUp", function($scope,$location,$http,createUser){
$scope.uploadFile = function(){
  createUser.signUpuser($scope.registration.user.name,$scope.registration.user.username,$scope.registration.user.email,$scope.registration.user.password,$scope.registration.user.gender,$scope.registration.user.myFile)
  }
});

app.controller("maincontroller",function($scope,$http,$location,createUser,Auth){
$scope.logOut=function(){
$http({
    method:"get",
    url:'/api/logout',
}).then(function successCallback(response){
  $scope.checkuser=false;
  $location.path('/login');
}, function errorCallback(res){
  console.log("error");
});

  }
})