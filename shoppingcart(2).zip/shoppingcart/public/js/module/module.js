var app = angular.module("myApp",['ngRoute','ngStorage','ngMessages','myApp.directives','ui.bootstrap']);
app.config(function($routeProvider){
 $routeProvider.
 when('/index',{
 controller: 'listblogcontroller',
 templateUrl: 'js/views/home.html'
 }).
 when('/addcart',{
 controller: 'listblogcontroller',
 templateUrl: 'js/views/addcart.html'
 }).
 when('/blog1',{
 controller: 'listblogcontroller',
 templateUrl: 'js/views/blog.html'
 }).
 when('/login',{
 controller:'Logincontroller',
 templateUrl: 'js/views/login.html'
 }).
 when('/signup',{
 controller:'signupcontroller',
 templateUrl: 'js/views/signup.html'
 }).
 when('/costumer',{
 controller:'listblogcontroller',
 templateUrl: 'js/views/costumer.html'
 }).
 when('/costumerdetail',{
 controller:'listblogcontroller',
 templateUrl: 'js/views/costumerdetails.html'
 }).
 when('/contact',{
 controller:'contactcontroller',
 templateUrl: 'js/views/contact.html'
 }).
 when('/profile',{
  controller:'Logincontroller',
 templateUrl: 'js/views/profile.html'
 }).
 when('/listblog',{
 controller:'listblogcontroller',
 templateUrl: 'js/views/listblog.html'
 }).
 when('/addblog',{
 controller:'addblogcontroller',
 templateUrl: 'js/views/addblog.html'
 }).
 when('/editblog',{
 controller:'listblogcontroller',
 templateUrl: 'js/views/editblog.html'
}).
 otherwise({
	 redirectTo:'/index'
	 });
	}); 


	