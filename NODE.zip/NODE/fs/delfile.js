var fs = require("fs");

fs.unlink('input.txt', function (err) {
   if (err){
      console.log(err);
      return;
   }
   console.log("file delete sucessfully");
});

 