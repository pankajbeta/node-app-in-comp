var fs = require("fs");

fs.open(__dirname +'/input.txt', 'r+' , function (err, data) {
   if (err){
      console.log(err.stack);
      return;
   }
   console.log(data);
});
console.log("file open sucessfully");
   