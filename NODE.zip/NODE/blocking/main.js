var fs = require("fs");

var data = fs.readFileSync('C:/Users/pankaj.sharma/Desktop/NODE/input.txt');

console.log(data.toString());
console.log("Program Ended");