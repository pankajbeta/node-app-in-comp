var fs = require("fs");

fs.readFile('C:/Users/pankaj.sharma/Desktop/NODE/nonBlocking/input.txt', function (err, data) {
    if (err) return console.error(err);
    console.log(data.toString());
});

console.log("Program Ended");