var buf = new Buffer([10, 20, 30, 40, 50]);

console.log(buf);

var buf1 = new Buffer(10);

console.log(buf1);

buf = new Buffer(256);
len = buf.write("Simply Easy Learning");

console.log("Octets written : "+  len);
//buffer to jayson
var buf = new Buffer('Simply Easy Learning');
var json = buf.toJSON(buf);

console.log(json);
//concat
var buffer1 = new Buffer('TutorialsPoint ');
var buffer2 = new Buffer('Simply Easy Learning');
var buffer3 = Buffer.concat([buffer1,buffer2]);
console.log("buffer3 content: " + buffer3.toString());

//slice
var buffer1 = new Buffer('TutorialsPoint');
//slicing a buffer
var buffer2 = buffer1.slice(0,9);
console.log("buffer2 content: " + buffer2.toString());