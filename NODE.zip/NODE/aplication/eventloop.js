
var events = require('events');
var eventEmitter = new events.EventEmitter();

// Create an event handler as follows
var connectHandler = function connected() {
   console.log('pankaj sharma'); 
}

// Bind the connection event with the handler
eventEmitter.on('connection', connectHandler);
 

// Fire the connection event 
eventEmitter.emit('connection');
